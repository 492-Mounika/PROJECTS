# Option A: Force the search path to be relative to the synthesis directory
set_db init_hdl_search_path {../../verilog_files/ .} 

# Option B: Or, explicitly point to the file relative to the 'work' directory
read_hdl ../../verilog_files/existing_aon_baseline.v
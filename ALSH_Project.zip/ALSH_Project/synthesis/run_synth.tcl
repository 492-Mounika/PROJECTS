# 1. Setup Technology (MMMC)
read_mmmc ../mmmc.tcl

# 2. Read the HDL
source ../read_hdl.tcl

# 3. Elaborate 
# Pointing to your specific top module name
elaborate existing_aon_baseline

# 4. Initialize the design 
init_design

# 5. Synthesis Stages
syn_generic
syn_map
syn_opt

# 6. Reports & Results (Paths relative to work/ directory)
mkdir -p reports
report_timing > reports/timing.rpt
report_area   > reports/area.rpt
report_power  > reports/power.rpt

mkdir -p results
write_hdl > results/existing_aon_baseline_netlist.v
write_sdc -view view_ss > results/existing_aon_baseline_netlist.sdc
## 1. Create Library Set (Timing)
create_library_set -name lib_ss_set \
    -timing {/PDK/tsmc28/stclib/9m/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn28hpcplusbwp30p140_180a/tcbn28hpcplusbwp30p140ssg0p9v125c_ccs.lib}

## 2. Create RC Corner (Physical Extraction)
create_rc_corner -name typical_rc \
    -qrc_tech "/PDK/tsmc28/pdk/qrcDeck/typical/qrcTechFile"

## 3. Create Delay Corner & Analysis View
create_timing_condition -name cond_ss -library_sets {lib_ss_set}
# Note: Path updated to find constraints.sdc in the synthesis folder
create_constraint_mode -name mode_func -sdc_files {../constraints.sdc}
create_delay_corner -name corner_ss -timing_condition {cond_ss} -rc_corner {typical_rc}
create_analysis_view -name view_ss -constraint_mode mode_func -delay_corner corner_ss

## 4. Set Active Views
set_analysis_view -setup {view_ss} -hold {view_ss}
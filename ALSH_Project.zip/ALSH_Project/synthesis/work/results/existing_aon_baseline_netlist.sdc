# ####################################################################

#  Created by Genus(TM) Synthesis Solution 20.10-p001_1 on Tue Apr 07 18:42:42 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design existing_aon_baseline

create_clock -name "clk" -period 2.0 -waveform {0.0 1.0} [get_ports clk]
set_load -pin_load 0.05 [get_ports wakeup_irq]
set_clock_gating_check -setup 0.0 
set_output_delay -clock [get_clocks clk] -add_delay 0.4 [get_ports wakeup_irq]
set_max_fanout 20.000 [current_design]
set_wire_load_mode "segmented"
set_clock_uncertainty -setup 0.1 [get_clocks clk]
set_clock_uncertainty -hold 0.1 [get_clocks clk]

add_search_path . /Application/Cadence/Installs/GENUS201/tools.lnx86/lib/tech -library -both
read_library -liberty -both /PDK/tsmc28/stclib/9m/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn28hpcplusbwp30p140_180a/tcbn28hpcplusbwp30p140ssg0p9v125c_ccs.lib


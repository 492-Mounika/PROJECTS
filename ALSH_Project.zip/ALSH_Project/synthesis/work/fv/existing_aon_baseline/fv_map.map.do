
//input ports
add mapped point clk clk -type PI PI
add mapped point rst_n rst_n -type PI PI
add mapped point sensor_in[11] sensor_in[11] -type PI PI
add mapped point sensor_in[10] sensor_in[10] -type PI PI
add mapped point sensor_in[9] sensor_in[9] -type PI PI
add mapped point sensor_in[8] sensor_in[8] -type PI PI
add mapped point sensor_in[7] sensor_in[7] -type PI PI
add mapped point sensor_in[6] sensor_in[6] -type PI PI
add mapped point sensor_in[5] sensor_in[5] -type PI PI
add mapped point sensor_in[4] sensor_in[4] -type PI PI
add mapped point sensor_in[3] sensor_in[3] -type PI PI
add mapped point sensor_in[2] sensor_in[2] -type PI PI
add mapped point sensor_in[1] sensor_in[1] -type PI PI
add mapped point sensor_in[0] sensor_in[0] -type PI PI
add mapped point threshold[11] threshold[11] -type PI PI
add mapped point threshold[10] threshold[10] -type PI PI
add mapped point threshold[9] threshold[9] -type PI PI
add mapped point threshold[8] threshold[8] -type PI PI
add mapped point threshold[7] threshold[7] -type PI PI
add mapped point threshold[6] threshold[6] -type PI PI
add mapped point threshold[5] threshold[5] -type PI PI
add mapped point threshold[4] threshold[4] -type PI PI
add mapped point threshold[3] threshold[3] -type PI PI
add mapped point threshold[2] threshold[2] -type PI PI
add mapped point threshold[1] threshold[1] -type PI PI
add mapped point threshold[0] threshold[0] -type PI PI

//output ports
add mapped point wakeup_irq wakeup_irq -type PO PO

//inout ports




//Sequential Pins
add mapped point wakeup_irq/q wakeup_irq_reg/Q  -type DFF DFF
add mapped point sync_reg_2[0]/q sync_reg_2_reg[0]/Q  -type DFF DFF
add mapped point sync_reg_2[3]/q sync_reg_2_reg[3]/Q  -type DFF DFF
add mapped point sync_reg_2[6]/q sync_reg_2_reg[6]/Q  -type DFF DFF
add mapped point sync_reg_2[2]/q sync_reg_2_reg[2]/Q  -type DFF DFF
add mapped point sync_reg_2[9]/q sync_reg_2_reg[9]/Q  -type DFF DFF
add mapped point sync_reg_2[5]/q sync_reg_2_reg[5]/Q  -type DFF DFF
add mapped point sync_reg_2[11]/q sync_reg_2_reg[11]/Q  -type DFF DFF
add mapped point sync_reg_2[7]/q sync_reg_2_reg[7]/Q  -type DFF DFF
add mapped point sync_reg_2[8]/q sync_reg_2_reg[8]/Q  -type DFF DFF
add mapped point sync_reg_2[1]/q sync_reg_2_reg[1]/Q  -type DFF DFF
add mapped point sync_reg_2[4]/q sync_reg_2_reg[4]/Q  -type DFF DFF
add mapped point sync_reg_2[10]/q sync_reg_2_reg[10]/Q  -type DFF DFF
add mapped point sync_reg_1[11]/q sync_reg_1_reg[11]/Q  -type DFF DFF
add mapped point sync_reg_1[5]/q sync_reg_1_reg[5]/Q  -type DFF DFF
add mapped point sync_reg_1[4]/q sync_reg_1_reg[4]/Q  -type DFF DFF
add mapped point sync_reg_1[1]/q sync_reg_1_reg[1]/Q  -type DFF DFF
add mapped point sync_reg_1[7]/q sync_reg_1_reg[7]/Q  -type DFF DFF
add mapped point sync_reg_1[6]/q sync_reg_1_reg[6]/Q  -type DFF DFF
add mapped point sync_reg_1[8]/q sync_reg_1_reg[8]/Q  -type DFF DFF
add mapped point sync_reg_1[0]/q sync_reg_1_reg[0]/Q  -type DFF DFF
add mapped point sync_reg_1[10]/q sync_reg_1_reg[10]/Q  -type DFF DFF
add mapped point sync_reg_1[3]/q sync_reg_1_reg[3]/Q  -type DFF DFF
add mapped point sync_reg_1[2]/q sync_reg_1_reg[2]/Q  -type DFF DFF
add mapped point sync_reg_1[9]/q sync_reg_1_reg[9]/Q  -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes

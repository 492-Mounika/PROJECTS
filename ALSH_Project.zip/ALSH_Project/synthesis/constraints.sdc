# Define the clock (Assumes your clock port is named 'clk')
# Period is in ns (e.g., 2.0ns = 500MHz)
create_clock -name clk -period 2.0 [get_ports clk]

# Set Clock Uncertainty (Jitter/Skew margin)
set_clock_uncertainty 0.1 [get_clocks clk]

# Set Input/Output Delays (Assuming 20% of clock period)
set_input_delay -clock clk 0.4 [all_inputs -not_touch clk]
set_output_delay -clock clk 0.4 [all_outputs]

# Set Load (Example load on output pins)
set_load 0.05 [all_outputs]

# Set Max Fanout
set_max_fanout 20 [current_design]
